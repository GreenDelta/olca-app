[Chart.js](https://github.com/nnnick/Chart.js) and 
[Chart.StackedBar.js](https://github.com/Regaddi/Chart.StackedBar.js)
are available under the [MIT license](http://opensource.org/licenses/MIT).  

The Chart.js version in this folder is a fork of Chart.js with a bug-fix:
https://github.com/msrocka/Chart.js.